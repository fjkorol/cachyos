[Appearance]
ColorScheme=Solarized
Font=Hack,11,-1,7,400,0,0,0,0,0,0,0,0,0,0,1,,0,0

[General]
Command=/bin/zsh
Environment=TERM=xterm-256color,COLORTERM=truecolor,KONSOLE_PROFILE_NAME=siu
Name=siu
Parent=FALLBACK/
